import { CustomSytleDirective } from './custom-sytle.directive';

describe('CustomSytleDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomSytleDirective();
    expect(directive).toBeTruthy();
  });
});
